# Wasabi’s Advanced Ambulance Job

## Documentation
https://docs.wasabiscripts.com/scripts/wasabi_ambulance
