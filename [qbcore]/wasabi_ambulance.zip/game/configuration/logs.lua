-----------------For support, scripts, and more----------------
--------------- https://discord.gg/wasabiscripts  -------------
---------------------------------------------------------------

SConfig = {
    deathLogs = {
        webhook = 'CHANGE_ME', -- Change to discord webhook / must have Config.DeathLogs enabled
        color = 15548997 -- Default: 15548997 (Red) - https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
    },
    reviveLogs = {
        webhook = 'CHANGE_ME', -- Change to discord webhook / must have Config.ReviveLogs enabled
        color = 15548997 -- Default: 15548997 (Red) - https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
    },
    combatLogs = {
        webhook = 'CHANGE_ME', -- Change to discord webhook / must have Config.ReviveLogs enabled
        color = 15548997 -- Default: 15548997 (Red) - https://gist.github.com/thomasbnt/b6f455e2c7d743b796917fa3c205f812
    },
}
